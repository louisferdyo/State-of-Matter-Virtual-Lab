const draggables = document.querySelectorAll('.draggable');
const dropZones = document.querySelectorAll('.drop-zone');
const feedback = document.getElementById('feedback');
const scoreDisplay = document.getElementById('scoreDisplay');
const openSidebarBtn = document.getElementById("open-sidebar");
const closeSidebarBtn = document.getElementById("close-sidebar");
const sidebar = document.getElementById("guide-sidebar");

let draggedItem = null; // Store the dragged item
let score = 0; // Initialize score

// Sidebar open/close functionality
openSidebarBtn.addEventListener("click", () => {
    sidebar.style.left = "0"; // Slide in the sidebar
    openSidebarBtn.style.display = "none";
});

closeSidebarBtn.addEventListener("click", () => {
    sidebar.style.left = "-450px"; // Slide out the sidebar
    openSidebarBtn.style.display = "block";
});

// Add desktop drag-and-drop events
draggables.forEach(item => {
    item.addEventListener('dragstart', () => startDrag(item));
    item.addEventListener('dragend', endDrag);

    // Add mobile touch events
    item.addEventListener('touchstart', (e) => startTouch(e, item));
    item.addEventListener('touchmove', moveTouch);
    item.addEventListener('touchend', (e) => endTouch(e));
});

// Add drop zone event listeners
dropZones.forEach(zone => {
    zone.addEventListener('dragover', (e) => e.preventDefault()); // Allow drop on desktop
    zone.addEventListener('drop', () => handleDrop(zone)); // Handle desktop drop
});

// Function to handle drag start (desktop)
function startDrag(item) {
    draggedItem = item;
    item.classList.add('dragging');
}

// Function to handle touch start (mobile)
function startTouch(e, item) {
    draggedItem = item;
    item.classList.add('dragging');

    const touch = e.touches[0];
    draggedItem.style.position = 'absolute';
    draggedItem.style.left = `${touch.pageX - item.offsetWidth / 2}px`;
    draggedItem.style.top = `${touch.pageY - item.offsetHeight / 2}px`;
}

// Function to move touch item (mobile)
function moveTouch(e) {
    const touch = e.touches[0];
    draggedItem.style.left = `${touch.pageX - draggedItem.offsetWidth / 2}px`;
    draggedItem.style.top = `${touch.pageY - draggedItem.offsetHeight / 2}px`;
}

// Function to handle touch end (mobile)
function endTouch(e) {
    const touch = e.changedTouches[0];
    const dropZone = document.elementFromPoint(touch.clientX, touch.clientY);

    if (dropZone && dropZone.classList.contains('drop-zone')) {
        handleDrop(dropZone); // Handle the drop
    } else {
        resetItem(draggedItem); // Reset the item if not dropped in a valid zone
    }
    endDrag(); // Clean up drag state
}

// Function to handle drag end (desktop and mobile)
function endDrag() {
    if (draggedItem) draggedItem.classList.remove('dragging');
    draggedItem = null;
}

// Function to handle the drop logic
function handleDrop(zone) {
    if (!draggedItem) return; // If no item is being dragged, do nothing

    if (isCorrectDrop(draggedItem, zone)) {
        zone.appendChild(draggedItem); // Place the item in the drop zone
        draggedItem.style.display = 'none'; // Hide the item after a correct drop
        score++; // Increment score
        feedback.textContent = "Correct! Well done!";
        scoreDisplay.textContent = `Score: ${score}`; // Update score display

        // Check if all items are placed correctly
        if (score === draggables.length) {
            feedback.textContent = "All answers are correct! Fantastic!";
        }
    } else {
        feedback.textContent = "Incorrect drop! Try again.";
        resetItem(draggedItem); // Reset the item to its original position
    }

    draggedItem = null; // Reset dragged item
}

// Function to check if the drop is correct
function isCorrectDrop(draggedItem, dropZone) {
    const correctAnswers = {
        'ice-description': 'solid-zone',
        'water-description': 'liquid-zone',
        'steam-description': 'gas-zone',
    };
    return dropZone.id === correctAnswers[draggedItem.id]; // Validate drop
}

// Function to reset the draggable item to its original position
function resetItem(item) {
    const originalParent = document.querySelector('.draggable-items');
    originalParent.appendChild(item); // Move back to original container
    item.style.display = 'block'; // Make it visible again
}
